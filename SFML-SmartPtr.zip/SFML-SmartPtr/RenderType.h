#pragma once

enum RenderType
{
	World,
	Screen,
};