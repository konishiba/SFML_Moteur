#include "RectangleActor.h"

RectangleActor::RectangleActor(const RectangleShapeData& _data) : MeshActor(_data)
{

}