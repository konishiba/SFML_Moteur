#include "Bird.h"

Bird::Bird() : MeshActor()
{
	
}


void Bird::BeginPlay()
{
	Super::BeginPlay();
}

void Bird::Tick(const float _deltaTime)
{
	Super::Tick(_deltaTime);
}