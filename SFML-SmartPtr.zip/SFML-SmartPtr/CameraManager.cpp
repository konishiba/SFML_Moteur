#include "CameraManager.h"

Camera::CameraManager::CameraManager()
{
	allElements = multimap<int, u_int>();
	allRendersData = map<u_int, RenderData>();
	allCameras = map<string, Shared<CameraActor>>();
	current = nullptr;
}


void Camera::CameraManager::RenderAllCameras(RenderWindow& _window)
{
	vector<RenderData> _renderWidgets;
	bool _isFirst = true;

	int _index = -1;
	for (const pair<int, u_int>& _element : allElements)
	{
		if (_element.first == _index) continue;

		_index = _element.first;
		using Iterator = multimap<int, u_int>::iterator;
		const pair<Iterator, Iterator>& _results = allElements.equal_range(_index);

		// Pour chaque cam�ra
		for (const pair<string, Shared<CameraActor>>& _pair : allCameras)
		{
			// Je d�finis la vue
			_window.setView(*_pair.second->GetView());

			// Je draw tous les �l�ments
			for (Iterator _it = _results.first; _it != _results.second; ++_it)
			{
				const RenderData& _data = allRendersData.at(_it->second);

				// Si il s'agit d'un widget
				if (_isFirst && _data.type == Screen)
				{
					// Je l'ajoute comme � afficher plus tard
					_renderWidgets.push_back(_data);
					continue;
				}

				// Je draw l'�l�ment
				_data.callback(_window);
			}

			_isFirst = false;
		}
	}

	// Je d�finis la vue
	_window.setView(_window.getDefaultView());

	for (const RenderData& _data : _renderWidgets)
	{
		// Je draw l'�l�ment
		_data.callback(_window);
	}
}

void Camera::CameraManager::UnbindOnRenderWindow(const u_int& _uniqueId)
{
	if (!allRendersData.contains(_uniqueId)) return;

	const int _zOrder = allRendersData.at(_uniqueId).zOrder;
	using Iterator = multimap<int, u_int>::iterator;
	const pair<Iterator, Iterator>& _results = allElements.equal_range(_zOrder);

	for (Iterator _it = _results.first; _it != _results.second; ++_it)
	{
		if (_it->second != _uniqueId) continue;
		allElements.erase(_it);
		break;
	}

	allRendersData.erase(_uniqueId);
}
